

###Version History########
## 202X-MM-DD	Ver 1.0 has released (creator: Shunichiro Orihara, Tokyo Medical Univ.)
##########################


###READ ME################
## Hogehoge
##########################


###PROGRAMS###############
###Estimation proposed by Orihara et al., 2023###
library(nleqslv)

EM_rep <- function(TT,CC,WW,XX1,XX2,VV,sd,rho_i,rho_u,rho_l,conv_rate,EM_iter,option=1){

EM_kk <- EM_iter   ##The number of iteration for EM algorithm
nn <- length(TT)   ##Sample size
aa <- ncol(XX1); bb <- ncol(XX2)   ##The number of parameters

##Initial parameter values
alpha <- rep(0,aa)
beta <- c(0.5,rep(0,bb-1))
rho <- rho_i
theta <- c(beta,alpha,rho)
lambda <- CC*rep(0.01,nn); theta2 <- c(theta,lambda)

if(option==1) alp0 <- 0   ###No intercept term
else if(option==2){
  alp0 <- glm(WW~XX1,family=binomial("probit"))$coef[1]   ###Include intercept term (two-step estimator)
}
else{
  print("Please select valid options")
  break
}

##Start EM algorithm
for(ll in 1:EM_kk){
EM_func <- function(theta2){
  ##Previous parameter value storing
  beta <- theta2[1:bb]
  alpha <- theta2[(bb+1):(bb+aa)]
  rho <- theta2[bb+aa+1]
  if(rho>rho_u|rho<rho_l) rho <- rho_l+(rho_u-rho_l)*rbeta(1,1.5,1.5)
  lambda <- theta2[(bb+aa+2):(bb+aa+1+nn)]
  Lambda <- cumsum(lambda)
  rho_ud <- max(1-rho^2,1-0.99^2)
  surv_lin <- c(XX2%*%beta)
  trt_lin <- alp0+c(XX1%*%alpha)
  
  ##Monte Carlo integration (approximation)
  fu_func1 <- function(uu,ii) return(mean(((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  fu_func2 <- function(uu,ii) return(mean(exp(uu)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  fu_func3 <- function(uu,ii) return(mean(uu*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  fu_func4 <- function(uu,ii) return(mean((uu^2)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  fu_func5 <- function(uu,ii) return(mean((uu^3)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  fu_func6 <- function(uu,ii) return(mean((uu^4)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  int_deno_ <- int01 <- int03 <- int04 <- int05 <- int06 <- rep(0,nn)
  for(jj in 1:nn){
    int_deno_[jj] <- fu_func1(VV[jj,],jj)
    int01[jj] <- fu_func2(VV[jj,],jj)
    int03[jj] <- fu_func3(VV[jj,],jj)
    int04[jj] <- fu_func4(VV[jj,],jj)
    int05[jj] <- fu_func5(VV[jj,],jj)
    int06[jj] <- fu_func6(VV[jj,],jj)
  }
  int_deno <- replace(int_deno_,int_deno_<=0,1e-100)
  
  ##Estimate the parameters
  optim_func <- function(theta){
    beta2 <- theta[1:bb]
    alpha2 <- theta[(bb+1):(bb+aa)]
    rho2 <- theta[bb+aa+1]
    if(rho2>rho_u|rho2<rho_l) rho2 <- rho_l+(rho_u-rho_l)*rbeta(1,1.5,1.5)
    rho_ud2 <- max(1-rho2^2,1-0.99^2)
    surv_lin2 <- c(XX2%*%beta2)
    
    int02_ <- rev(cumsum(exp(rev(surv_lin2+log(int01/int_deno)))))
    int02 <- replace(int02_,int02_<=0,1e-100)
    int02_2 <- apply(apply(exp(rev(surv_lin2+log(int01/int_deno)))*apply(XX2,2,rev),2,cumsum),2,rev)
    LF1 <- apply(CC*XX2-CC*(int02_2/int02),2,sum,na.rm=T)
    
    trt_lin2 <- alp0+XX1%*%alpha2
    pnorm_1_ <- pnorm(trt_lin2)
    pnorm_0_ <- 1-pnorm(trt_lin2)
    pnorm_1 <- replace(pnorm_1_,pnorm_1_<=0,1e-50); pnorm_0 <- replace(pnorm_0_,pnorm_0_<=0,1e-50)
    dnorm <- dnorm(trt_lin2)
    phi2 <- -trt_lin2*dnorm
    phi3 <- -(1-trt_lin2^2)*dnorm
    phi4 <- trt_lin2*(3-trt_lin2^2)*dnorm
    LF21 <- t(cbind(XX1,(XX1%*%alpha2*rho2+(int03/int_deno)/sd)/rho_ud2))%*%(WW*(dnorm/pnorm_1+rho2^2/2*trt_lin2*(phi2/pnorm_1-dnorm^2/pnorm_1^2))-(1-WW)*(dnorm/pnorm_0+rho2^2/2*trt_lin2*(phi2/pnorm_0+dnorm^2/pnorm_0^2)))
    LF22 <- (rho2/sd)*t(cbind(XX1*(int03/int_deno),(XX1%*%alpha2*rho2*(int03/int_deno)+(int04/int_deno)/sd)/rho_ud2))%*%(WW*(phi2/pnorm_1-dnorm^2/pnorm_1^2+0.5*rho2^2*trt_lin2*(phi3/pnorm_1-3*phi2*dnorm/pnorm_1^2+2*dnorm^3/pnorm_1^3)+0.5*rho2^2*(phi2/pnorm_1-dnorm^2/pnorm_1^2))-(1-WW)*(phi2/pnorm_0+dnorm^2/pnorm_0^2+0.5*rho2^2*trt_lin2*(phi3/pnorm_0+3*phi2*dnorm/pnorm_0^2+2*dnorm^3/pnorm_0^3)+0.5*rho2^2*(phi2/pnorm_0+dnorm^2/pnorm_0^2)))
    LF23 <- (rho2/sd)^2*t(cbind(XX1*(int04/int_deno),(XX1%*%alpha2*rho2*(int04/int_deno)+(int05/int_deno)/sd)/rho_ud2))%*%(WW*(phi3/pnorm_1-3*phi2*dnorm/pnorm_1^2+2*dnorm^3/pnorm_1^3)-(1-WW)*(phi3/pnorm_0+3*phi2*dnorm/pnorm_0^2+2*dnorm^3/pnorm_0^3))
    LF24 <- (rho2/sd)^3*t(cbind(XX1*(int05/int_deno),(XX1%*%alpha2*rho2*(int05/int_deno)+(int06/int_deno)/sd)/rho_ud2))%*%(WW*(phi4/pnorm_1-(4*phi3*dnorm+3*phi2^2)/pnorm_1^2+12*dnorm^2*phi2/pnorm_1^3-6*dnorm^4/pnorm_1^4)-(1-WW)*(phi4/pnorm_0+(4*phi3*dnorm+3*phi2^2)/pnorm_0^2+12*dnorm^2*phi2/pnorm_0^3+6*dnorm^4/pnorm_0^4))
    LF2 <- (LF21+LF22+LF23/2+LF24/6)/sqrt(rho_ud2)
    
    return(c(LF1,LF2))
  }
  beta_post <- nleqslv(x=c(beta,alpha,rho),fn=optim_func)$x
  return(c(beta_post))
}
##Subsequent parameter value storing
beta_update <- EM_func(theta2)

##Update of parameter values
beta <- beta_update[1:bb]
alpha <- beta_update[(bb+1):(bb+aa)]
rho <- beta_update[bb+aa+1]
rho_ud <- max(1-rho^2,1-0.99^2)
Lambda <- cumsum(lambda)
surv_lin <- c(XX2%*%beta)
trt_lin <- alp0+c(XX1%*%alpha)

fu_func1_ <- function(uu,ii) return(mean(((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
fu_func2_ <- function(uu,ii) return(mean(exp(uu)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))

int_deno_ <- int01 <- rep(0,nn)
for(jj in 1:nn){
  int_deno_[jj] <- fu_func1_(VV[jj,],jj)
  int01[jj] <- fu_func2_(VV[jj,],jj)
}

##Update the baseline hazard
int_deno <- replace(int_deno_,int_deno_<=0,1e-100)
lambda_ <- CC*(1/rev(cumsum(exp(rev(surv_lin+log(int01/int_deno))))))
lambda <- replace(lambda_,which(is.na(lambda_)),0)

##Checking convergence sufficiently or not
if((sum(abs(theta2[c(1:bb,bb+aa+1)]-beta_update[c(1:bb,bb+aa+1)]))>=conv_rate)&ll<EM_kk) theta2 <- c(beta_update,lambda)
else{
  theta2 <- c(beta_update,lambda)
  break
}
}

##Final parameter values
beta2 <- theta2[1:bb]
alpha2 <- theta2[(bb+1):(bb+aa)]
rho2 <- theta2[bb+aa+1]
rho_ud2 <- max(1-rho2^2,1-0.99^2)
lambda <- theta2[(bb+aa+2):(bb+aa+1+nn)]
Lambda <- cumsum(lambda)
surv_lin <- c(XX2%*%beta2)
trt_lin <- alp0+c(XX1%*%alpha2)

##Calculating the variance covariance matrix
fu_func1 <- function(uu,ii) return(mean(((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
fu_func2 <- function(uu,ii) return(mean(exp(uu)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
fu_func3 <- function(uu,ii) return(mean(uu*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
fu_func4 <- function(uu,ii) return(mean((uu^2)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
fu_func5 <- function(uu,ii) return(mean((uu^3)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
fu_func6 <- function(uu,ii) return(mean((uu^4)*((lambda[ii]*exp(surv_lin[ii]+uu))^CC[ii])*exp(-Lambda[ii]*exp(surv_lin[ii]+uu))*(pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud))*WW[ii]+(1-pnorm((trt_lin[ii]+rho*uu/sd)/sqrt(rho_ud)))*(1-WW[ii]))))
  
int_deno_ <- int01 <- int03 <- int04 <- int05 <- int06 <- rep(0,nn)
for(jj in 1:nn){
  int_deno_[jj] <- fu_func1(VV[jj,],jj)
  int01[jj] <- fu_func2(VV[jj,],jj)
  int03[jj] <- fu_func3(VV[jj,],jj)
  int04[jj] <- fu_func4(VV[jj,],jj)
  int05[jj] <- fu_func5(VV[jj,],jj)
  int06[jj] <- fu_func6(VV[jj,],jj)
}
int_deno <- replace(int_deno_,int_deno_<=0,1e-100)
  
surv_lin2 <- c(XX2%*%beta2)
int02_ <- rev(cumsum(exp(rev(surv_lin2+log(int01/int_deno)))))
int02 <- replace(int02_,int02_<=0,1e-100)
int02_2 <- apply(apply(exp(rev(surv_lin2+log(int01/int_deno)))*apply(XX2,2,rev),2,cumsum),2,rev)
LF1 <- CC*XX2-CC*(int02_2/int02)

trt_lin2 <- c(alp0+XX1%*%alpha2)
pnorm_1_ <- pnorm(trt_lin2)
pnorm_0_ <- 1-pnorm(trt_lin2)
pnorm_1 <- replace(pnorm_1_,pnorm_1_<=0,1e-50); pnorm_0 <- replace(pnorm_0_,pnorm_0_<=0,1e-50)
dnorm <- dnorm(trt_lin2)
phi2 <- -trt_lin2*dnorm
phi3 <- -(1-trt_lin2^2)*dnorm
phi4 <- trt_lin2*(3-trt_lin2^2)*dnorm

LF21 <- (cbind(XX1,(XX1%*%alpha2*rho2+(int03/int_deno)/sd)/rho_ud2))*c(WW*(dnorm/pnorm_1+rho2^2/2*trt_lin2*(phi2/pnorm_1-dnorm^2/pnorm_1^2))-(1-WW)*(dnorm/pnorm_0+rho2^2/2*trt_lin2*(phi2/pnorm_0+dnorm^2/pnorm_0^2)))
LF22 <- (rho2/sd)*(cbind(XX1*(int03/int_deno),(XX1%*%alpha2*rho2*(int03/int_deno)+(int04/int_deno)/sd)/rho_ud2))*c(WW*(phi2/pnorm_1-dnorm^2/pnorm_1^2+0.5*rho2^2*trt_lin2*(phi3/pnorm_1-3*phi2*dnorm/pnorm_1^2+2*dnorm^3/pnorm_1^3)+0.5*rho2^2*(phi2/pnorm_1-dnorm^2/pnorm_1^2))-(1-WW)*(phi2/pnorm_0+dnorm^2/pnorm_0^2+0.5*rho2^2*trt_lin2*(phi3/pnorm_0+3*phi2*dnorm/pnorm_0^2+2*dnorm^3/pnorm_0^3)+0.5*rho2^2*(phi2/pnorm_0+dnorm^2/pnorm_0^2)))
LF23 <- (rho2/sd)^2*(cbind(XX1*(int04/int_deno),(XX1%*%alpha2*rho2*(int04/int_deno)+(int05/int_deno)/sd)/rho_ud2))*c(WW*(phi3/pnorm_1-3*phi2*dnorm/pnorm_1^2+2*dnorm^3/pnorm_1^3)-(1-WW)*(phi3/pnorm_0+3*phi2*dnorm/pnorm_0^2+2*dnorm^3/pnorm_0^3))
LF24 <- (rho2/sd)^3*(cbind(XX1*(int05/int_deno),(XX1%*%alpha2*rho2*(int05/int_deno)+(int06/int_deno)/sd)/rho_ud2))*c(WW*(phi4/pnorm_1-(4*phi3*dnorm+3*phi2^2)/pnorm_1^2+12*dnorm^2*phi2/pnorm_1^3-6*dnorm^4/pnorm_1^4)-(1-WW)*(phi4/pnorm_0+(4*phi3*dnorm+3*phi2^2)/pnorm_0^2+12*dnorm^2*phi2/pnorm_0^3+6*dnorm^4/pnorm_0^4))
LF2 <- (LF21+LF22+LF23/2+LF24/6)/sqrt(rho_ud2)

DD <- cbind(LF1,LF2)
DD_ <- solve(t(DD)%*%DD/nn)   ##the variance covariance matrix

###Observed log-likelihood
ll1 <- sum(log(lambda[CC==1]))+sum(CC*surv_lin2)+sum(CC*apply(VV,1,mean))-sum(Lambda*exp(surv_lin2)*sum(apply(exp(VV),1,mean)))
ll2 <- sum(WW*apply(log(pnorm((trt_lin2+VV*rho2/sd)/sqrt(1-rho^2))),1,mean))+sum((1-WW)*apply(log(1-pnorm((trt_lin2+VV*rho2/sd)/sqrt(1-rho^2))),1,mean))

##Return the estimating results
if(ll<EM_kk) return(list(beta_update,ll,DD_,ll1+ll2))
else return(list(beta_update,"Not convergence",DD_,ll1+ll2))
}
##########################


###EXAMPLES###############
##Hogehoge
##########################



