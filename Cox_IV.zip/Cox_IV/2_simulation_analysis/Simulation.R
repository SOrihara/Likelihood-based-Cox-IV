

library(MASS); library(survival)
#rm(list = ls(all.names = TRUE))

#Data column
##ID: 1, IV: 36, Covariates: 34, 35
##Simulation number: 42
##Survival_time: from 2 to 9
##Censor: from 10 to 17
##Treatment: from 18 to 25
##Unmeasured covariates from 26 to 33

data1 <- read.csv("~/Desktop/D_Orihara/Simulation_SurvEM/Surv_data")
#data1 <- read.csv("C:/Users/81908/Desktop/TTE/Surv_data")
#data1 <- read.csv("C:/Users/Taguri/Desktop/Orihara/_temp/Surv_data")
#data1 <- read.csv("~/Desktop/D_Orihara/Simulation_SurvEM/Surv_data_copula")


source("~/Desktop/D_Orihara/Simulation_SurvEM/LIML_TTE_9.R")
#source("C:/Users/81908/Desktop/TTE/LIML_TTE.R")
#source("C:/Users/Taguri/Desktop/Orihara/_temp/LIML_TTE_5.R")



nn <- 500
KK <- 500

kekka_K <- kekka_K2 <- count_KK <- rep(0,KK)
kekka <- SE_KK <- matrix(0,ncol=KK,nrow=6)

count <- 0

sd1=0.45
BB <- 1.5*nn
BB_ini <- 1*nn*BB
u_vec <- rnorm(BB_ini,sd=sd1)
VV <- matrix(u_vec[sample(1:BB_ini,BB*nn,replace=T)],ncol=BB)
#VV <- matrix(u_vec)


for(mm in 1:KK){
data_anl <- subset(data1,data1[,1]<=nn&data1[,ncol(data1)]==mm)

##Change column number
TT <- data_anl[,5]
CNSR <- data_anl[,13]
WW <- data_anl[,21]
UU <- data_anl[,29]

ZZ <- data_anl[,36]
XX <- data_anl[,34:35]


surv_data <- cbind(TT,CNSR,WW,ZZ,XX,UU)
surv_data2 <- surv_data[order(surv_data[,1]),]

TT <- surv_data2[,1]; CC <- surv_data2[,2]; WW <- surv_data2[,3]
ZZ <- surv_data2[,4]; XX <- surv_data2[,5:6]; UU <- surv_data2[,7]


##Partial likelihood
kekka_K[mm] <- coxph(Surv(TT,CC)~WW+XX[,2])$coef[1]
kekka_K2[mm] <- coxph(Surv(TT,CC)~WW+XX[,2]+UU)$coef[1]

##Proposed method
#kk1 <- EM_rep(TT=TT,CC=CC,WW=WW,XX1=cbind(ZZ,XX[,1],XX[,2]),XX2=cbind(WW,XX[,2]),VV=VV,sd=sd1,rho_i=0.3,rho_u=0.8,rho_l=0.2,conv_rate=1e-3,EM_iter=200)
kk1 <- EM_rep(TT=TT,CC=CC,WW=WW,XX1=cbind(ZZ,XX[,1],XX[,2]),XX2=cbind(WW,XX[,2]),VV=VV,sd=sd1,rho_i=-0.3,rho_u=-0.2,rho_l=-0.8,conv_rate=1e-3,EM_iter=200)

kekka[,mm] <- kk1[[1]]
count_KK[mm] <- kk1[[2]]
SE_KK[,mm] <- diag(kk1[[3]])

CIL <- kekka[1,mm]+qnorm(0.025)*sqrt(SE_KK[1,mm]/nn)
CIU <- kekka[1,mm]+qnorm(0.975)*sqrt(SE_KK[1,mm]/nn)

count <- count+1; print(c(count,mean(kekka[1,1:mm]),sum(CIL >= 0.5|CIU <= 0.5),count_KK[mm]))
}


LL <- KK

CI <- matrix(0,nrow=KK,ncol=3)
CI[,1] <- kekka[1,]
CI[,2] <- kekka[1,]+qnorm(0.025)*sqrt(c(SE_KK[1,])/nn)
CI[,3] <- kekka[1,]+qnorm(0.975)*sqrt(c(SE_KK[1,])/nn)

1-sum(CI[1:LL,2] >= 0.5|CI[1:LL,3] <= 0.5)/LL

summary(CI[1:LL,])
summary(t(kekka)[1:LL,])


k_kekka <- data.frame(t((rbind(kekka[1,],kekka_K,kekka_K2,kekka[nrow(kekka),],t(CI[,2:3])))))
k_kekka2 <- data.frame(t(SE_KK))
names(k_kekka) <- c("Proposed","Ordinary","Ordinary (infeasible)","Proposed (corr)","Proposed (LCI)","Proposed (UCI)")
names(k_kekka2) <- c("SE (beta)","SE (alpha)","SE (rho)")

summary(k_kekka[1:LL,])

#pdf("~/Desktop/D_Orihara/Simulation_SurvEM/zu2.pdf",width=12,height=8)
boxplot(k_kekka[1:LL,])
abline(h=0.5,col="red",lty=2,lwd=3)
#dev.off()

#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n200_SIV",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n200_SIV",row.names=F)
#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n200_WIV",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n200_WIV",row.names=F)
#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n200_SNCR",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n200_SNCR",row.names=F)
#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n200_WPCR",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n200_WPCR",row.names=F)
#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n500_SPCR",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n500_SPCR",row.names=F)

#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n1000_tcp",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n1000_tcp",row.names=F)
#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n1000_clcp",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n1000_clcp",row.names=F)

write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n500_SIV_sdumis",row.names=F)
write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n500_SIV_sdumis",row.names=F)

#write.csv(k_kekka,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_n500_SIV_sdlmis",row.names=F)
#write.csv(k_kekka2,"~/Desktop/D_Orihara/Simulation_SurvEM/kekka_SE_n500_SIV_sdlmis",row.names=F)

