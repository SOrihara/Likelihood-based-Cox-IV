

rm(list = ls(all.names = TRUE))
set.seed(20221213)
library(MASS)
library(copula)

nn <- 2000
KK <- 1000

for(kk in 1:KK){
XX1 <- rnorm(nn,0,5)
XX2 <- rbinom(nn,1,0.3)

#Unmeasured covariates
##Weak negative corr.
sigma <- 0.35
##t copula
cop_FF1 <- rCopula(nn,copula=tCopula(param=0.3,dim=2))
UU_1 <- cbind(qnorm(cop_FF1[,1]),qnorm(cop_FF1[,2],sd=sigma))

##Clayton copula
cop_FF2 <- rCopula(nn,copula=claytonCopula(param=0.5,dim=2))
UU_2 <- cbind(qnorm(cop_FF2[,1]),qnorm(cop_FF2[,2],sd=sigma))

#Valid IV
ZZ <-  rgamma(nn,2,1)
#hist(ZZ)

##Treatment
WW_11 <- WW_21 <- WW_12 <- WW_22 <- rep(0,nn)
for(ii in 1:nn){
  ##Weak IV & t copula
  if(0.05*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_1[ii,1]>0) WW_11[ii] <- 1
  ##Strong IV & t copula
  if(0.15*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_1[ii,1]>0) WW_21[ii] <- 1
  ##Weak IV & Clayton copula
  if(0.03*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_2[ii,1]>0) WW_12[ii] <- 1
  ##Strong IV & Clayton copula
  if(0.15*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_2[ii,1]>0) WW_22[ii] <- 1
}

#cor(ZZ,cbind(WW_11,WW_21,WW_12,WW_22),method="spearman")
#cor(cbind(WW_11,WW_21),UU_1,method="spearman")
#cor(cbind(WW_12,WW_22),UU_2,method="spearman")
#mean(WW_11); mean(WW_21)
#mean(WW_12); mean(WW_22)


#Hazard function, Survival function, and Censor
bs_hzd <- 1
hzd_11 <- bs_hzd*exp(0.5*WW_11-0.5*XX2+UU_1[,2])
hzd_21 <- bs_hzd*exp(0.5*WW_21-0.5*XX2+UU_1[,2])
hzd_12 <- bs_hzd*exp(0.5*WW_12-0.5*XX2+UU_2[,2])
hzd_22 <- bs_hzd*exp(0.5*WW_22-0.5*XX2+UU_2[,2])


cnsr_prm=12
CNSR_dst_11 <- runif(nn,0,cnsr_prm)
CNSR_dst_21 <- runif(nn,0,cnsr_prm)
CNSR_dst_12 <- runif(nn,0,cnsr_prm)
CNSR_dst_22 <- runif(nn,0,cnsr_prm)

TT_11 <- TT_21 <- TT_12 <- TT_22 <- rep(0,nn)
CNSR_11 <- CNSR_21 <- CNSR_12 <- CNSR_22 <- rep(0,nn)
for(ii in 1:nn){
  TT_11[ii] <- rexp(1,rate=hzd_11[ii])
  TT_21[ii] <- rexp(1,rate=hzd_21[ii])
  TT_12[ii] <- rexp(1,rate=hzd_12[ii])
  TT_22[ii] <- rexp(1,rate=hzd_22[ii])
#}
  if(TT_11[ii] < CNSR_dst_11[ii]) CNSR_11[ii] <- 1
  else TT_11[ii] <- CNSR_dst_11[ii]
  if(TT_21[ii] < CNSR_dst_21[ii]) CNSR_21[ii] <- 1
  else TT_21[ii] <- CNSR_dst_21[ii]
  if(TT_12[ii] < CNSR_dst_12[ii]) CNSR_12[ii] <- 1
  else TT_12[ii] <- CNSR_dst_12[ii]
  if(TT_22[ii] < CNSR_dst_22[ii]) CNSR_22[ii] <- 1
  else TT_22[ii] <- CNSR_dst_22[ii]
}

#hist(c(TT_11,TT_21,TT_12,TT_22))
#cor(cbind(WW_11,UU_1),cbind(TT_11),method="spearman"); cor(cbind(WW_21,UU_1),cbind(TT_21),method="spearman")
#cor(cbind(WW_12,UU_2),cbind(TT_12),method="spearman"); cor(cbind(WW_22,UU_2),cbind(TT_22),method="spearman")

#mean(CNSR_11); mean(CNSR_21)
#mean(CNSR_12); mean(CNSR_22)


#Sample ID
ID <- 1:nn

surv_data <- cbind(ID,TT_11,TT_21,TT_12,TT_22,
			 CNSR_11,CNSR_21,CNSR_12,CNSR_22,
			 WW_11,WW_21,WW_12,WW_22,UU_1,UU_2,XX1,XX2,ZZ,kk)

if(kk==1) surv_data2 <- surv_data
else surv_data2 <- rbind(surv_data2,surv_data)
}


write.csv(surv_data2,"~/Desktop/D_Orihara/Simulation_SurvEM/Surv_data_copula",row.names=F)
#write.csv(surv_data2,"C:/Users/Taguri/Desktop/Orihara/_temp/Surv_data",row.names=F)
#write.csv(surv_data2,"C:/Users/81908/Desktop/博論_予備発表/3_シミュレーション/Surv_data",row.names=F)





