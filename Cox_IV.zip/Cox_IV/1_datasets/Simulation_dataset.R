

rm(list = ls(all.names = TRUE))
set.seed(20221213)
library(MASS)

nn <- 2000
KK <- 1000

for(kk in 1:KK){
XX1 <- rnorm(nn,0,5)
XX2 <- rbinom(nn,1,0.3)

#Unmeasured covariates
##Weak negative corr.
sigma <- 0.35^2
rho_1 <- -0.3*sqrt(sigma)
sigma_1 <- c(1,rho_1,rho_1,sigma); Sigma_1 <- matrix(sigma_1,ncol=2)
UU_1 <- mvrnorm(nn,c(0,0),Sigma_1)

##Strong negative corr.
rho_2 <- -0.6*sqrt(sigma)
sigma_2 <- c(1,rho_2,rho_2,sigma); Sigma_2 <- matrix(sigma_2,ncol=2)
UU_2 <- mvrnorm(nn,c(0,0),Sigma_2)

##Weak positive corr.
rho_3 <- 0.3*sqrt(sigma)
sigma_3 <- c(1,rho_3,rho_3,sigma); Sigma_3 <- matrix(sigma_3,ncol=2)
UU_3 <- mvrnorm(nn,c(0,0),Sigma_3)

##Strong positive corr.
rho_4 <- 0.6*sqrt(sigma)
sigma_4 <- c(1,rho_4,rho_4,sigma); Sigma_4 <- matrix(sigma_4,ncol=2)
UU_4 <- mvrnorm(nn,c(0,0),Sigma_4)

#Valid IV
ZZ <-  rgamma(nn,2,1)
#hist(ZZ)

##Treatment
WW_11 <- WW_21 <- WW_12 <- WW_22 <- WW_13 <- WW_23 <- WW_14 <- WW_24 <- rep(0,nn)
for(ii in 1:nn){
  ##Weak IV & Weak neg corr
  if(0.05*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_1[ii,1]>0) WW_11[ii] <- 1
  ##Strong IV & Weak neg corr
  if(0.15*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_1[ii,1]>0) WW_21[ii] <- 1
  ##Weak IV & Strong neg corr
  if(0.03*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_2[ii,1]>0) WW_12[ii] <- 1
  ##Strong IV & Strong neg corr
  if(0.15*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_2[ii,1]>0) WW_22[ii] <- 1
  ##Weak IV & Weak pos corr
  if(0.03*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_3[ii,1]>0) WW_13[ii] <- 1
  ##Strong IV & Weak pos corr
  if(0.15*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_3[ii,1]>0) WW_23[ii] <- 1
  ##Weak IV & Strong pos corr
  if(0.03*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_4[ii,1]>0) WW_14[ii] <- 1
  ##Strong IV & Strong pos corr
  if(0.15*ZZ[ii]+0.05*XX1[ii]-0.5*XX2[ii]+UU_4[ii,1]>0) WW_24[ii] <- 1
}

#cor(ZZ,cbind(WW_11,WW_21,WW_12,WW_22,WW_13,WW_23,WW_14,WW_24),method="spearman")
#cor(cbind(WW_11,WW_21),UU_1,method="spearman")
#cor(cbind(WW_12,WW_22),UU_2,method="spearman")
#cor(cbind(WW_13,WW_23),UU_3,method="spearman")
#cor(cbind(WW_14,WW_24),UU_4,method="spearman")
#mean(WW_11); mean(WW_21)
#mean(WW_12); mean(WW_22)
#mean(WW_13); mean(WW_23)
#mean(WW_14); mean(WW_24)


#Hazard function, Survival function, and Censor
bs_hzd <- 1
hzd_11 <- bs_hzd*exp(0.5*WW_11-0.5*XX2+UU_1[,2])
hzd_21 <- bs_hzd*exp(0.5*WW_21-0.5*XX2+UU_1[,2])
hzd_12 <- bs_hzd*exp(0.5*WW_12-0.5*XX2+UU_2[,2])
hzd_22 <- bs_hzd*exp(0.5*WW_22-0.5*XX2+UU_2[,2])
hzd_13 <- bs_hzd*exp(0.5*WW_13-0.5*XX2+UU_3[,2])
hzd_23 <- bs_hzd*exp(0.5*WW_23-0.5*XX2+UU_3[,2])
hzd_14 <- bs_hzd*exp(0.5*WW_14-0.5*XX2+UU_4[,2])
hzd_24 <- bs_hzd*exp(0.5*WW_24-0.5*XX2+UU_4[,2])


cnsr_prm=12
CNSR_dst_11 <- runif(nn,0,cnsr_prm)
CNSR_dst_21 <- runif(nn,0,cnsr_prm)
CNSR_dst_12 <- runif(nn,0,cnsr_prm)
CNSR_dst_22 <- runif(nn,0,cnsr_prm)
CNSR_dst_13 <- runif(nn,0,cnsr_prm)
CNSR_dst_23 <- runif(nn,0,cnsr_prm)
CNSR_dst_14 <- runif(nn,0,cnsr_prm)
CNSR_dst_24 <- runif(nn,0,cnsr_prm)

TT_11 <- TT_21 <- TT_12 <- TT_22 <- TT_13 <- TT_23 <- TT_14 <- TT_24 <- rep(0,nn)
CNSR_11 <- CNSR_21 <- CNSR_12 <- CNSR_22 <- CNSR_13 <- CNSR_23 <- CNSR_14 <- CNSR_24 <- rep(0,nn)
for(ii in 1:nn){
  TT_11[ii] <- rexp(1,rate=hzd_11[ii])
  TT_21[ii] <- rexp(1,rate=hzd_21[ii])
  TT_12[ii] <- rexp(1,rate=hzd_12[ii])
  TT_22[ii] <- rexp(1,rate=hzd_22[ii])
  TT_13[ii] <- rexp(1,rate=hzd_13[ii])
  TT_23[ii] <- rexp(1,rate=hzd_23[ii])
  TT_14[ii] <- rexp(1,rate=hzd_14[ii])
  TT_24[ii] <- rexp(1,rate=hzd_24[ii])
#}
  if(TT_11[ii] < CNSR_dst_11[ii]) CNSR_11[ii] <- 1
  else TT_11[ii] <- CNSR_dst_11[ii]
  if(TT_21[ii] < CNSR_dst_21[ii]) CNSR_21[ii] <- 1
  else TT_21[ii] <- CNSR_dst_21[ii]
  if(TT_12[ii] < CNSR_dst_12[ii]) CNSR_12[ii] <- 1
  else TT_12[ii] <- CNSR_dst_12[ii]
  if(TT_22[ii] < CNSR_dst_22[ii]) CNSR_22[ii] <- 1
  else TT_22[ii] <- CNSR_dst_22[ii]
  if(TT_13[ii] < CNSR_dst_13[ii]) CNSR_13[ii] <- 1
  else TT_13[ii] <- CNSR_dst_13[ii]
  if(TT_23[ii] < CNSR_dst_23[ii]) CNSR_23[ii] <- 1
  else TT_23[ii] <- CNSR_dst_23[ii]
  if(TT_14[ii] < CNSR_dst_14[ii]) CNSR_14[ii] <- 1
  else TT_14[ii] <- CNSR_dst_14[ii]
  if(TT_24[ii] < CNSR_dst_24[ii]) CNSR_24[ii] <- 1
  else TT_24[ii] <- CNSR_dst_24[ii]
}

#hist(c(TT_11,TT_21,TT_12,TT_22))
#cor(cbind(WW_11,UU_1),cbind(TT_11),method="spearman"); cor(cbind(WW_21,UU_1),cbind(TT_21),method="spearman")
#cor(cbind(WW_12,UU_2),cbind(TT_12),method="spearman"); cor(cbind(WW_22,UU_2),cbind(TT_22),method="spearman")
#cor(cbind(WW_13,UU_3),cbind(TT_13),method="spearman"); cor(cbind(WW_23,UU_3),cbind(TT_23),method="spearman")
#cor(cbind(WW_14,UU_4),cbind(TT_14),method="spearman"); cor(cbind(WW_24,UU_4),cbind(TT_24),method="spearman")

mean(CNSR_11); mean(CNSR_21)
mean(CNSR_12); mean(CNSR_22)
mean(CNSR_13); mean(CNSR_23)
mean(CNSR_14); mean(CNSR_24)


#Sample ID
ID <- 1:nn

surv_data <- cbind(ID,TT_11,TT_21,TT_12,TT_22,TT_13,TT_23,TT_14,TT_24,
			 CNSR_11,CNSR_21,CNSR_12,CNSR_22,CNSR_13,CNSR_23,CNSR_14,CNSR_24,
			 WW_11,WW_21,WW_12,WW_22,WW_13,WW_23,WW_14,WW_24,UU_1,UU_2,UU_3,UU_4,XX1,XX2,ZZ,kk)

if(kk==1) surv_data2 <- surv_data
else surv_data2 <- rbind(surv_data2,surv_data)
}


write.csv(surv_data2,"~/Desktop/D_Orihara/Simulation_SurvEM/Surv_data",row.names=F)
#write.csv(surv_data2,"C:/Users/Taguri/Desktop/Orihara/_temp/Surv_data",row.names=F)
#write.csv(surv_data2,"C:/Users/81908/Desktop/博論_予備発表/3_シミュレーション/Surv_data",row.names=F)





