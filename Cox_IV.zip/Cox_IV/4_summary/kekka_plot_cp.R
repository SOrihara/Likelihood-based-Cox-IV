

data2 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_clcp")[,1:3]
data1 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_tcp")[,1:3]

names(data1) <- names(data2) <- c("Proposed","Naive","Infeasible")

kk1 <- list(data1,data2)
names(kk1) <- c("Heavy-tailed dist.","Asymmetry dist.")


pdf("C:/Users/81908/Desktop/kekka_surv_cox/_summary/zu3_cox.pdf",width=10,height=14)
par(mfrow=c(2,1))

par(mgp=c(3,2,0))
boxplot(exp(kk1[[1]]),ylim=c(0.5,3.5),ylab="Estimated hazard ratio",locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[1])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[2]]),ylim=c(0.5,3.5),locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[2])
legend("topleft",legend=labels,cex=0.8,bg = "white")

dev.off()

