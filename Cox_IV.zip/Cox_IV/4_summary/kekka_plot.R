

data1 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n200_SIV")[,1:3]
data3 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n200_WIV")[,1:3]
data5 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n200_SNCR")[,1:3]
data7 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n200_SPCR")[,1:3]
data2 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_SIV")[,1:3]
data4 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_WIV")[,1:3]
data6 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_SNCR")[,1:3]
data8 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_SPCR")[,1:3]

names(data1) <- names(data2) <- names(data3) <- names(data4) <- c("Proposed","Naive","Infeasible")
names(data5) <- names(data6) <- names(data7) <- names(data8) <- c("Proposed","Naive","Infeasible")

kk1 <- list(data1,data2,data3,data4,data5,data6,data7,data8)
names(kk1) <- c("Scenario #1: n=200","Scenario #1: n=500",
                "Scenario #2: n=200","Scenario #2: n=500",
                "Scenario #3: n=200","Scenario #3: n=500",
                "Scenario #4: n=200","Scenario #4: n=500")



pdf("C:/Users/81908/Desktop/kekka_surv_cox/_summary/zu1_cox.pdf",width=12,height=14)
par(mfrow=c(2,2))

par(mgp=c(3,2,0))
boxplot(exp(kk1[[1]]),ylim=c(0.5,3.5),ylab="Estimated hazard ratio",locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[1])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[2]]),ylim=c(0.5,3.5),locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[2])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[3]]),ylim=c(0.5,3.5),ylab="Estimated hazard ratio",locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[3])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[4]]),ylim=c(0.5,3.5),locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[4])
legend("topleft",legend=labels,cex=0.8,bg = "white")

dev.off()


pdf("C:/Users/81908/Desktop/kekka_surv_cox/_summary/zu2_cox.pdf",width=12,height=14)
par(mfrow=c(2,2))

par(mgp=c(3,2,0))
boxplot(exp(kk1[[5]]),ylim=c(0.5,3.5),ylab="Estimated hazard ratio",locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[5])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[6]]),ylim=c(0.5,3.5),locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[6])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[7]]),ylim=c(0.5,3.5),ylab="Estimated hazard ratio",locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[7])
legend("topleft",legend=labels,cex=0.8,bg = "white")

par(mgp=c(3,2,0))
boxplot(exp(kk1[[8]]),ylim=c(0.5,3.5),locations=c(-5,0),yaxt="n")
abline(h=exp(0.5),col="red",lty=2,lwd=3)
par(mgp=c(1,1,0))
axis(side=2,at=seq(0.5,3.5,by=0.5))
labels <- names(kk1[8])
legend("topleft",legend=labels,cex=0.8,bg = "white")

dev.off()


