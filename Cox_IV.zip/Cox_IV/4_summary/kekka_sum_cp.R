

rm(list = ls(all.names = TRUE))
library(Hmisc)


data2 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_clcp")
data1 <- read.csv("C:/Users/81908/Desktop/kekka_surv_cox/kekka_n500_tcp")

CI1 <- CI2 <- CI3 <- CI4 <- matrix(0,nrow=500,ncol=4)
CI1[,1] <- data1[,1]; CI1[,2] <- data1[,5]; CI1[,3] <- data1[,6]
CI2[,1] <- data2[,1]; CI2[,2] <- data2[,5]; CI2[,3] <- data2[,6]

#1-sum(CI1[,2] >= 0.5|CI1[,3] <= 0.5)/500
#1-sum(CI2[,2] >= 0.5|CI2[,3] <= 0.5)/500
#1-sum(CI3[,2] >= 0.5|CI3[,3] <= 0.5)/500
#1-sum(CI4[,2] >= 0.5|CI4[,3] <= 0.5)/500


#summary(CI1); summary(CI2); summary(CI3); summary(CI4)

sum_func <- function(output){
  kk1 <- data.frame(PMC = paste0("Proposed"),
                    P1 = paste0(format(round(mean(exp(data1[,1])),digits=3),nsmall=3)),
                    P2 = paste0(format(round(sd(exp(data1[,1])),digits=3),nsmall=3)),
                    P3 = paste0(format(round(100*abs(mean(exp(data1[,1]))-exp(0.5))/exp(0.5),digits=3),nsmall=3)),
                    P4 = paste0(format(round(sqrt(var(exp(data1[,1]))+(mean(exp(data1[,1]))-exp(0.5))^2),digits=3),nsmall=3)),
                    P5 = paste0(format(round(1-sum(CI1[,2] >= 0.5|CI1[,3] <= 0.5)/500,digits=3),nsmall=3))
  )
  kk2 <- data.frame(PMC = paste0("Naive"),
                    P1 = paste0(format(round(mean(exp(data1[,2])),digits=3),nsmall=3)),
                    P2 = paste0(format(round(sd(exp(data1[,2])),digits=3),nsmall=3)),
                    P3 = paste0(format(round(100*abs(mean(exp(data1[,2]))-exp(0.5))/exp(0.5),digits=3),nsmall=3)),
                    P4 = paste0(format(round(sqrt(var(exp(data1[,2]))+(mean(exp(data1[,2]))-exp(0.5))^2),digits=3),nsmall=3)),
                    P5 = paste0("-")
  )
  kk3 <- data.frame(PMC = paste0("Infeasible"),
                    P1 = paste0(format(round(mean(exp(data1[,3])),digits=3),nsmall=3)),
                    P2 = paste0(format(round(sd(exp(data1[,3])),digits=3),nsmall=3)),
                    P3 = paste0(format(round(100*abs(mean(exp(data1[,3]))-exp(0.5))/exp(0.5),digits=3),nsmall=3)),
                    P4 = paste0(format(round(sqrt(var(exp(data1[,3]))+(mean(exp(data1[,3]))-exp(0.5))^2),digits=3),nsmall=3)),
                    P5 = paste0("-")
  )
  kk4 <- data.frame(PMC = paste0("Proposed"),
                    P1 = paste0(format(round(mean(exp(data2[,1])),digits=3),nsmall=3)),
                    P2 = paste0(format(round(sd(exp(data2[,1])),digits=3),nsmall=3)),
                    P3 = paste0(format(round(100*abs(mean(exp(data2[,1]))-exp(0.5))/exp(0.5),digits=3),nsmall=3)),
                    P4 = paste0(format(round(sqrt(var(exp(data2[,1]))+(mean(exp(data2[,1]))-exp(0.5))^2),digits=3),nsmall=3)),
                    P5 = paste0(format(round(1-sum(CI2[,2] >= 0.5|CI2[,3] <= 0.5)/500,digits=3),nsmall=3))
  )
  kk5 <- data.frame(PMC = paste0("Naive"),
                    P1 = paste0(format(round(mean(exp(data2[,2])),digits=3),nsmall=3)),
                    P2 = paste0(format(round(sd(exp(data2[,2])),digits=3),nsmall=3)),
                    P3 = paste0(format(round(100*abs(mean(exp(data2[,2]))-exp(0.5))/exp(0.5),digits=3),nsmall=3)),
                    P4 = paste0(format(round(sqrt(var(exp(data2[,2]))+(mean(exp(data2[,2]))-exp(0.5))^2),digits=3),nsmall=3)),
                    P5 = paste0("-")
  )
  kk6 <- data.frame(PMC = paste0("Infeasible"),
                    P1 = paste0(format(round(mean(exp(data2[,3])),digits=3),nsmall=3)),
                    P2 = paste0(format(round(sd(exp(data2[,3])),digits=3),nsmall=3)),
                    P3 = paste0(format(round(100*abs(mean(exp(data2[,3]))-exp(0.5))/exp(0.5),digits=3),nsmall=3)),
                    P4 = paste0(format(round(sqrt(var(exp(data2[,3]))+(mean(exp(data2[,3]))-exp(0.5))^2),digits=3),nsmall=3)),
                    P5 = paste0("-")
  )
  
  kk1 <- rbind(kk1,kk2,kk3,kk4,kk5,kk6)
  rownames(kk1) <- c("Heavy-tailed dist.","dmy1","dmy2",
                     "Asymmetry dist.","dmy3","dmy4")
  latex(kk1,file=output)
}

sum_func(output="C:/Users/81908/Desktop/kekka_surv_cox/_summary/kk_sum_cp_n500_K500")







